import java.text.NumberFormat;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int room_selected;
        boolean isParking, isTv, isKitchen, isWifi, isGarden, isAc, isBalcony;
        NumberFormat formatter=NumberFormat.getCurrencyInstance(Locale.US);

//        create room_charge_calc instance
        RoomChargeCalculator room_charge_calc = new RoomChargeCalculator();

//        created the initial menu
        System.out.print("Room Charge Calculator");
        System.out.println();
        System.out.print("1. Delux-Double");
        System.out.println();
        System.out.print("2. Standard-Family");
        System.out.println();
        System.out.print("3. Standard-Single");
        System.out.println();
        System.out.print("Quit");
        System.out.println();

//        your choice section
        Scanner scan_value = new Scanner(System.in);
        System.out.print("Enter your choice(1-4) : ");
        room_selected = scan_value.nextInt();
        System.out.println();

//        input validation
        switch (room_selected) {
            case 1 :
                try{
                    System.out.println("Delux-Double is Selected");
                    System.out.print("Is parking is used (true or false) : ");
                    isParking = scan_value.nextBoolean();
                    System.out.println();
                    System.out.print("Is balcony is used (true or false) : ");
                    isBalcony = scan_value.nextBoolean();
                    System.out.println();
                    System.out.print("Is tv is used (true or false) : ");
                    isTv = scan_value.nextBoolean();
                    System.out.println();
                    System.out.print("Is kitchen used (true or false) : ");
                    isKitchen = scan_value.nextBoolean();
                    System.out.println();
                    System.out.print("Is wifi is used (true or false) : ");
                    isWifi = scan_value.nextBoolean();
                    System.out.println();
                    System.out.println("Total Fee : " + formatter.format(room_charge_calc.getChargeDeluxDouble(isBalcony, isParking, isTv, isKitchen, isWifi)));

                }
                catch (InputMismatchException ex){
                    System.out.println("Input true or false only");
                    System.out.println(ex.getMessage());
                    System.exit(-1);
                }
                break;


            case 2 :
                try{
                    System.out.println("Standard-Family is Selected");
                    System.out.print("Is parking is used (true or false) : ");
                    isParking = scan_value.nextBoolean();
                    System.out.println();
                    System.out.print("Is kitchen is used (true or false) : ");
                    isKitchen = scan_value.nextBoolean();
                    System.out.println();
                    System.out.print("Is garden is used (true or false) : ");
                    isGarden = scan_value.nextBoolean();
                    System.out.println();
                    System.out.println("Total Fee : " + formatter.format(room_charge_calc.getChargeStandardFamily(isParking, isKitchen, isGarden)));

                }
                catch (InputMismatchException ex){
                    System.out.println("Input true or false only");
                    System.out.println(ex.getMessage());
                    System.exit(-1);
                }
                break;


            case 3 :
                try{
                    System.out.println("Standard-Single is Selected");
                    System.out.print("Is parking is used (true or false) : ");
                    isParking = scan_value.nextBoolean();
                    System.out.println();
                    System.out.print("Is AC is used (true or false) : ");
                    isAc = scan_value.nextBoolean();
                    System.out.println();
                    System.out.print("Is wifi is used (true or false) : ");
                    isWifi = scan_value.nextBoolean();
                    System.out.println();
                    System.out.println("Total Fee : " + formatter.format(room_charge_calc.getStandardSingle(isParking, isAc, isWifi)));

                }
                catch (InputMismatchException ex) {
                    System.out.println("Input true or false only");
                    System.out.println(ex.getMessage());
                    System.exit(-1);
                }
                break;


            case 4 : System.exit(0);
            default :
                System.out.println("Invalid Input");
                System.exit(-1);

        }

        scan_value.close();
    }
}

