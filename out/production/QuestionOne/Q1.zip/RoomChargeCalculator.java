//    room charge calculator class definition
public class RoomChargeCalculator {

    int FixedFee;
    int balconyFee;
    int parkingFee;
    int tvFee;
    int kitchenFee;
    int wifiFee;
    int acFee;
    int gardenFee;
    int totalFee;

    int getChargeDeluxDouble(boolean isBalcony, boolean isParking, boolean isTv, boolean isKitchen, boolean isWifi){
        FixedFee = 5000;
        balconyFee = 500;
        parkingFee = 200;
        tvFee = 200;
        kitchenFee = 1000;
        wifiFee = 100;

        totalFee = FixedFee;

        if(isBalcony) totalFee += balconyFee;
        if(isParking) totalFee += parkingFee;
        if(isTv) totalFee += tvFee;
        if(isKitchen) totalFee += kitchenFee;
        if(isWifi) totalFee += wifiFee;

        return totalFee;
    }

    int getChargeStandardFamily(boolean isParking, boolean isKitchen, boolean isGarden){
        FixedFee = 3000;
        parkingFee = 200;
        kitchenFee = 500;
        gardenFee = 200;

        totalFee = FixedFee;

        if(isParking) totalFee += parkingFee;
        if(isKitchen) totalFee += kitchenFee;
        if(isGarden) totalFee += gardenFee;

        return totalFee;
    }

    int getStandardSingle(boolean isParking, boolean isAc, boolean isWifi){
        FixedFee = 2000;
        parkingFee = 200;
        acFee = 500;
        wifiFee = 100;

        totalFee = FixedFee;

        if(isParking) totalFee += parkingFee;
        if(isAc) totalFee += acFee;
        if(isWifi) totalFee += wifiFee;

        return totalFee;
    }
}
